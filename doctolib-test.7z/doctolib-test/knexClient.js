import knex from 'knex'
import config from './knexfile'

export default knex(config.development)
